import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_curve, precision_recall_curve,
    roc_auc_score, auc
)
import warnings
warnings.filterwarnings("ignore")

# === Step 1: Load Cleaned Datasets ===
teams_df = pd.read_csv("C:/Users/varsh/OneDrive/Desktop/football_cup/cleaned_data/final_48_teams_enriched_cleaned.csv")
fixtures_df = pd.read_csv("C:/Users/varsh/OneDrive/Desktop/football_cup/cleaned_data/fifa_2026_fixtures_enriched_cleaned.csv")

# === Step 2: Label Finalists Manually ===
teams_df["is_finalist"] = teams_df["team"].apply(lambda x: 1 if x in ["Argentina", "France"] else 0)

# === Step 3: Aggregate Match Stats Per Team ===
home_stats = fixtures_df.groupby("home_team")[["home_defence", "home_midfield", "home_attack"]].mean().reset_index()
away_stats = fixtures_df.groupby("away_team")[["away_defence", "away_midfield", "away_attack"]].mean().reset_index()
home_stats.columns = ["team", "home_defense", "home_midfield", "home_attack"]
away_stats.columns = ["team", "away_defense", "away_midfield", "away_attack"]

# === Step 4: Merge Team-Level and Match-Level Features ===
df = teams_df.merge(home_stats, on="team", how="left").merge(away_stats, on="team", how="left")
df.fillna(-1, inplace=True)
df["mean_defense_score"] = df[["home_defense", "away_defense"]].mean(axis=1)
df["mean_midfield_score"] = df[["home_midfield", "away_midfield"]].mean(axis=1)
df["mean_attack_score"] = df[["home_attack", "away_attack"]].mean(axis=1)

# === Step 5: Filter Out Weak Rows ===
df_filtered = df[
    (df["fifa_rank"] != -1) &
    (df["mean_defense_score"] != -1) &
    (df["mean_midfield_score"] != -1) &
    (df["mean_attack_score"] != -1)
]

# === Step 6: Select Features and Target ===
features = ["fifa_rank", "confederation", "mean_defense_score", "mean_midfield_score", "mean_attack_score"]
X = df_filtered[features]
y = df_filtered["is_finalist"]

# === Step 7: Manual Train-Test Split to Ensure Finalist in Test Set ===
finalists = df_filtered[df_filtered["is_finalist"] == 1]
non_finalists = df_filtered[df_filtered["is_finalist"] == 0]
test_finalists = finalists.sample(n=1, random_state=42)
test_non_finalists = non_finalists.sample(n=9, random_state=42)
test_df = pd.concat([test_finalists, test_non_finalists])
train_df = df_filtered.drop(test_df.index)
X_train = train_df[features]
y_train = train_df["is_finalist"]
X_test = test_df[features]
y_test = test_df["is_finalist"]

# === Step 8: Preprocessing ===
numeric_features = ["fifa_rank", "mean_defense_score", "mean_midfield_score", "mean_attack_score"]
categorical_features = ["confederation"]
preprocessor = ColumnTransformer(transformers=[
    ("num", StandardScaler(), numeric_features),
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features)
])

# === Step 9: Define Pipelines with Class Balancing ===
lr_pipeline = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("classifier", LogisticRegression(max_iter=1000, class_weight='balanced'))
])
rf_pipeline = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(class_weight='balanced'))
])

# === Step 10: Train Logistic Regression ===
lr_pipeline.fit(X_train, y_train)
y_pred_lr = lr_pipeline.predict(X_test)

# === Step 11: Train Random Forest with Tuning ===
param_grid = {
    "classifier__n_estimators": [100, 200],
    "classifier__max_depth": [5, 10]
}
grid_rf = GridSearchCV(rf_pipeline, param_grid, cv=3)
grid_rf.fit(X_train, y_train)
y_pred_rf = grid_rf.predict(X_test)

# === Step 12: Save Evaluation Results ===
with open("C:/Users/varsh/OneDrive/Desktop/football_cup/task2_evaluation_report.txt", "w") as f:
    f.write("=== Logistic Regression Results ===\n")
    f.write(classification_report(y_test, y_pred_lr))
    f.write("\nConfusion Matrix:\n")
    f.write(str(confusion_matrix(y_test, y_pred_lr)))
    f.write("\n\n=== Random Forest Results ===\n")
    f.write(classification_report(y_test, y_pred_rf))
    f.write("\nConfusion Matrix:\n")
    f.write(str(confusion_matrix(y_test, y_pred_rf)))
    f.write("\nBest Parameters: " + str(grid_rf.best_params_))

# === Step 13: Save Predictions to CSV ===
output_df = X_test.copy()
output_df["true_label"] = y_test.values
output_df["lr_prediction"] = y_pred_lr
output_df["rf_prediction"] = y_pred_rf
output_df.to_csv("C:/Users/varsh/OneDrive/Desktop/football_cup/task2_model_predictions.csv", index=False)

# === Step 14: Visualize All Evaluation Metrics ===
cm_lr = confusion_matrix(y_test, y_pred_lr)
cm_rf = confusion_matrix(y_test, y_pred_rf)
labels = ["Non-Finalist", "Finalist"]
lr_fpr, lr_tpr, _ = roc_curve(y_test, y_pred_lr)
rf_fpr, rf_tpr, _ = roc_curve(y_test, y_pred_rf)
lr_auc = roc_auc_score(y_test, y_pred_lr)
rf_auc = roc_auc_score(y_test, y_pred_rf)
lr_prec, lr_rec, _ = precision_recall_curve(y_test, y_pred_lr)
rf_prec, rf_rec, _ = precision_recall_curve(y_test, y_pred_rf)
lr_pr_auc = auc(lr_rec, lr_prec)
rf_pr_auc = auc(rf_rec, rf_prec)

plt.style.use('seaborn-v0_8')
fig, axs = plt.subplots(2, 3, figsize=(15, 10))

sns.heatmap(cm_lr, annot=True, fmt="d", cmap="Blues", xticklabels=labels, yticklabels=labels, ax=axs[0, 0])
axs[0, 0].set_title("Logistic Regression Confusion Matrix")
axs[0, 0].set_xlabel("Predicted")
axs[0, 0].set_ylabel("Actual")

sns.heatmap(cm_rf, annot=True, fmt="d", cmap="Greens", xticklabels=labels, yticklabels=labels, ax=axs[0, 1])
axs[0, 1].set_title("Random Forest Confusion Matrix")
axs[0, 1].set_xlabel("Predicted")
axs[0, 1].set_ylabel("Actual")

axs[0, 2].plot(lr_fpr, lr_tpr, label=f"Logistic Regression (AUC={lr_auc:.2f})", color="blue")
axs[0, 2].plot(rf_fpr, rf_tpr, label=f"Random Forest (AUC={rf_auc:.2f})", color="green")
axs[0, 2].plot([0, 1], [0, 1], 'k--', lw=1)
axs[0, 2].set_title("ROC Curve")
axs[0, 2].set_xlabel("False Positive Rate")
axs[0, 2].set_ylabel("True Positive Rate")
axs[0, 2].legend()

axs[1, 0].plot(lr_rec, lr_prec, label=f"Logistic Regression (AUC={lr_pr_auc:.2f})", color="blue")
axs[1, 0].plot(rf_rec, rf_prec, label=f"Random Forest (AUC={rf_pr_auc:.2f})", color="green")
axs[1, 0].set_title("Precision-Recall Curve")
axs[1, 0].set_xlabel("Recall")
axs[1, 0].set_ylabel("Precision")
axs[1, 0].legend()

axs[1, 1].axis("off")
axs[1, 2].axis("off")

plt.tight_layout()
plt.savefig("C:/Users/varsh/OneDrive/Desktop/football_cup/task2_model_visuals.png")
import joblib
joblib.dump(grid_rf, "C:/Users/varsh/OneDrive/Desktop/football_cup/grid_rf_model.pkl")
import joblib
joblib.dump(lr_pipeline, "C:/Users/varsh/OneDrive/Desktop/football_cup/lr_pipeline_model.pkl")