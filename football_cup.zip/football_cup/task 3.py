import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, precision_recall_curve, auc

# === Step 1: True labels and predictions ===
y_test = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0]
y_pred_lr = [1, 0, 0, 0, 0, 0, 1, 0, 0, 0]
y_pred_rf = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# === Step 2: Convert predictions to probabilities ===
y_score_lr = [0.9 if p == 1 else 0.1 for p in y_pred_lr]
y_score_rf = [0.6 if p == 1 else 0.4 for p in y_pred_rf]

# === Step 3: Compute ROC and PR curves ===
fpr_lr, tpr_lr, _ = roc_curve(y_test, y_score_lr)
fpr_rf, tpr_rf, _ = roc_curve(y_test, y_score_rf)
roc_auc_lr = auc(fpr_lr, tpr_lr)
roc_auc_rf = auc(fpr_rf, tpr_rf)

precision_lr, recall_lr, _ = precision_recall_curve(y_test, y_score_lr)
precision_rf, recall_rf, _ = precision_recall_curve(y_test, y_score_rf)
pr_auc_lr = auc(recall_lr, precision_lr)
pr_auc_rf = auc(recall_rf, precision_rf)

# === Step 4: Plot ROC and PR curves ===
fig, axs = plt.subplots(1, 2, figsize=(12, 5))

# ROC Curve
axs[0].plot(fpr_lr, tpr_lr, label=f"Logistic Regression (AUC = {roc_auc_lr:.2f})", color="blue")
axs[0].plot(fpr_rf, tpr_rf, label=f"Random Forest (AUC = {roc_auc_rf:.2f})", color="green")
axs[0].plot([0, 1], [0, 1], linestyle="--", color="gray")
axs[0].set_title("ROC Curve")
axs[0].set_xlabel("False Positive Rate")
axs[0].set_ylabel("True Positive Rate")
axs[0].legend()

# Precision-Recall Curve
axs[1].plot(recall_lr, precision_lr, label=f"Logistic Regression (AUC = {pr_auc_lr:.2f})", color="blue")
axs[1].plot(recall_rf, precision_rf, label=f"Random Forest (AUC = {pr_auc_rf:.2f})", color="green")
axs[1].set_title("Precision-Recall Curve")
axs[1].set_xlabel("Recall")
axs[1].set_ylabel("Precision")
axs[1].legend()

plt.tight_layout()
plt.savefig("C:/Users/varsh/OneDrive/Desktop/football_cup/model_curves.png")
plt.show()