import joblib
import matplotlib.pyplot as plt
import numpy as np

# === Load Trained Model from Task 2 ===
model_path = "C:/Users/varsh/OneDrive/Desktop/football_cup/grid_rf_model.pkl"
grid_rf = joblib.load(model_path)

# === Define Feature Names (same as Task 2) ===
numeric_features = ["fifa_rank", "mean_defense_score", "mean_midfield_score", "mean_attack_score"]
categorical_features = ["confederation"]

# Extract one-hot encoded feature names from fitted encoder
encoder = grid_rf.best_estimator_.named_steps["preprocessor"].named_transformers_["cat"]
encoded_categories = encoder.get_feature_names_out(categorical_features)

# Combine all feature names
all_features = numeric_features + list(encoded_categories)

# === Extract Feature Importances ===
rf_model = grid_rf.best_estimator_.named_steps["classifier"]
importances = rf_model.feature_importances_

# === Sort and Plot ===
sorted_idx = np.argsort(importances)[::-1]
sorted_features = [all_features[i] for i in sorted_idx]
sorted_importances = importances[sorted_idx]

plt.figure(figsize=(10, 6))
plt.barh(sorted_features, sorted_importances, color="teal")
plt.gca().invert_yaxis()
plt.title("Task 4: Feature Importance from Random Forest")
plt.xlabel("Importance Score")
plt.tight_layout()
plt.savefig("C:/Users/varsh/OneDrive/Desktop/football_cup/task4_feature_importance.png")
plt.show()