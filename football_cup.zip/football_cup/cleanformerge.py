import pandas as pd
import os

# Input and output paths
input_path = "C:/Users/varsh/OneDrive/Desktop/football_cup/merged_fifa_data.csv"
output_folder = "C:/Users/varsh/OneDrive/Desktop/football_cup/cleaned_data"
output_path = os.path.join(output_folder, "merged_fifa_data_cleaned.csv")

# Ensure output folder exists
os.makedirs(output_folder, exist_ok=True)

try:
    print("Loading merged_fifa_data.csv...")
    # Load with memory optimization
    df = pd.read_csv(input_path, encoding="utf-8", low_memory=False)

    # Standardize column names
    df.columns = [str(col).strip().lower().replace(" ", "_") for col in df.columns]

    # Clean each column safely
    for col in df.columns:
        try:
            if df[col].dtype == "object":
                df[col] = df[col].astype(str).str.strip().replace("nan", "")
                df[col] = df[col].fillna("Unknown")
            else:
                df[col] = df[col].fillna(-1)
        except Exception as col_error:
            print(f"Skipped column '{col}' due to error: {col_error}")

    # Drop empty columns and duplicate rows
    df = df.dropna(axis=1, how="all")
    df = df.drop_duplicates()

    # Save cleaned file
    df.to_csv(output_path, index=False, encoding="utf-8")

    print("Cleaned file saved to:", output_path)
    print("Rows:", len(df), "| Columns:", len(df.columns))

except Exception as e:
    print("Error cleaning merged_fifa_data.csv:", e)