import pandas as pd
import os

# Folder containing cleaned CSVs
folder = "C:/Users/varsh/OneDrive/Desktop/football_cup/cleaned_data"

# List all CSV files
csv_files = [f for f in os.listdir(folder) if f.endswith(".csv")]

# Inspect each file
for filename in csv_files:
    path = os.path.join(folder, filename)
    print(f"\n--- {filename} ---")
    try:
        df = pd.read_csv(path, encoding="utf-8", low_memory=False)

        # Show column names
        print("Columns:")
        print(df.columns.tolist())

        # Show null value counts
        print("\nNull values per column:")
        print(df.isnull().sum())

        # Optional: show shape
        print("\nShape:", df.shape)

    except Exception as e:
        print(f"Error reading {filename}: {e}")