import pandas as pd

# Load final 48 teams (just team names)
final_teams = pd.read_csv("C:/Users/varsh/OneDrive/Desktop/football_cup/final_48_teams.csv")
final_teams["team"] = final_teams["team"].astype(str).str.strip().str.title()

# Load qualified team info (with confederation and rank)
qualified_info = pd.read_csv("C:/Users/varsh/OneDrive/Desktop/football_cup/qualified_teams_2026_enriched.csv")
qualified_info["team"] = qualified_info["team"].astype(str).str.strip().str.title()

# Merge to enrich final list with confederation and rank (where available)
merged = final_teams.merge(qualified_info, on="team", how="left")

# Fill missing confederation/rank for predicted teams
merged["confederation"] = merged["confederation"].fillna("Unknown")
merged["fifa_rank"] = merged["fifa_rank"].fillna(-1).astype(int)

# Save to a new file
output_path = "C:/Users/varsh/OneDrive/Desktop/football_cup/final_48_teams_enriched.csv"
merged.to_csv(output_path, index=False)

print("Enriched final team list saved as:", output_path)
print(" Sample:")
print(merged.head(10))