import pandas as pd
import matplotlib.pyplot as plt
import joblib

# === Step 1: Load Trained Logistic Regression Model ===
model_path = "C:/Users/varsh/OneDrive/Desktop/football_cup/lr_pipeline_model.pkl"
lr_pipeline = joblib.load(model_path)

# === Step 2: Load 2026 Qualified Teams Dataset ===
qualified_df = pd.read_csv("C:/Users/varsh/OneDrive/Desktop/football_cup/cleaned_data/qualified_teams_2026_enriched_cleaned.csv")

# === Step 3: Aggregate Match Stats Per Team ===
fixtures_df = pd.read_csv("C:/Users/varsh/OneDrive/Desktop/football_cup/cleaned_data/fifa_2026_fixtures_enriched_cleaned.csv")
home_stats = fixtures_df.groupby("home_team")[["home_defence", "home_midfield", "home_attack"]].mean().reset_index()
away_stats = fixtures_df.groupby("away_team")[["away_defence", "away_midfield", "away_attack"]].mean().reset_index()
home_stats.columns = ["team", "home_defense", "home_midfield", "home_attack"]
away_stats.columns = ["team", "away_defense", "away_midfield", "away_attack"]

# === Step 4: Merge Features ===
df = qualified_df.merge(home_stats, on="team", how="left").merge(away_stats, on="team", how="left")
df.fillna(-1, inplace=True)
df["mean_defense_score"] = df[["home_defense", "away_defense"]].mean(axis=1)
df["mean_midfield_score"] = df[["home_midfield", "away_midfield"]].mean(axis=1)
df["mean_attack_score"] = df[["home_attack", "away_attack"]].mean(axis=1)

# === Step 5: Filter Valid Rows ===
df_filtered = df[
    (df["fifa_rank"] != -1) &
    (df["mean_defense_score"] != -1) &
    (df["mean_midfield_score"] != -1) &
    (df["mean_attack_score"] != -1)
]

# === Step 6: Select Features and Predict ===
features = ["fifa_rank", "confederation", "mean_defense_score", "mean_midfield_score", "mean_attack_score"]
X_new = df_filtered[features]
probs = lr_pipeline.predict_proba(X_new)[:, 1]  # Probability of being a finalist

# === Step 7: Save Predictions ===
df_filtered["finalist_probability"] = probs
df_filtered_sorted = df_filtered.sort_values(by="finalist_probability", ascending=False)
df_filtered_sorted.to_csv("C:/Users/varsh/OneDrive/Desktop/football_cup/task5_finalist_predictions.csv", index=False)

# === Step 8: Plot Top 10 Predictions ===
top10 = df_filtered_sorted.head(10)
plt.figure(figsize=(10, 6))
plt.barh(top10["team"], top10["finalist_probability"], color="darkorange")
plt.gca().invert_yaxis()
plt.title("Task 5: Top 10 Predicted Finalists (Logistic Regression)")
plt.xlabel("Predicted Probability")
plt.tight_layout()
plt.savefig("C:/Users/varsh/OneDrive/Desktop/football_cup/task5_top10_predictions.png")
plt.show()