import pandas as pd
import os

# Input and output folders
input_folder = "C:/Users/varsh/OneDrive/Desktop/football_cup"
output_folder = "C:/Users/varsh/OneDrive/Desktop/football_cup/cleaned_data"

# Ensure output folder exists
os.makedirs(output_folder, exist_ok=True)

# List all CSV files in the input folder
csv_files = [f for f in os.listdir(input_folder) if f.endswith(".csv")]

# Loop through each file and clean
for filename in csv_files:
    input_path = os.path.join(input_folder, filename)
    print(f"\n Cleaning file: {filename}")
    try:
        # Load file with safe encoding and memory handling
        df = pd.read_csv(input_path, encoding="utf-8", low_memory=False)

        # Standardize column names
        df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]

        # Clean each column
        for col in df.columns:
            if df[col].dtype == "object":
                df[col] = df[col].astype(str).str.strip().replace("nan", "")
                df[col] = df[col].fillna("Unknown")
            else:
                df[col] = df[col].fillna(-1)

        # Drop empty columns and duplicate rows
        df = df.dropna(axis=1, how="all")
        df = df.drop_duplicates()

        # Save cleaned version to output folder
        cleaned_name = filename.replace(".csv", "_cleaned.csv")
        output_path = os.path.join(output_folder, cleaned_name)
        df.to_csv(output_path, index=False, encoding="utf-8")

        print(f" Saved cleaned file to: {output_path}")
        print(f" Rows: {len(df)}, Columns: {len(df.columns)}")

    except Exception as e:
        print(f" Error cleaning {filename}: {e}")