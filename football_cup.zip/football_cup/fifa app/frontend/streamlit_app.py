import streamlit as st
import pandas as pd
import joblib

# Page setup
st.set_page_config(page_title="Your Road to the 2026 FIFA World Cup Final", layout="centered")

# Custom styling
st.markdown("""
    <style>
    body {
        background-color: #f0f8ff;
    }
    .main h1 {
        color: #003366;
        font-size: 36px;
        text-align: center;
    }
    .stButton>button {
        background-color: #003366;
        color: white;
        font-weight: bold;
    }
    .stSelectbox label, .stMultiselect label {
        font-weight: bold;
        color: #003366;
    }
    </style>
""", unsafe_allow_html=True)

# Load model and data
try:
    model = joblib.load("../lr_pipeline_model.pkl")
    df = pd.read_csv("../qualified_teams_2026_enriched.csv")
except FileNotFoundError as e:
    st.error(f"Missing file: {e}")
    st.stop()

teams = sorted(df["team"].dropna().unique())

# Session state
for key in ["stage", "qf_winners", "sf_winner", "champion", "final_opponent"]:
    if key not in st.session_state:
        st.session_state[key] = None

def predict(team_name):
    row = df[df["team"] == team_name].copy()
    if row.empty:
        return None
    rank = row["fifa_rank"].values[0]
    row["mean_defense_score"] = max(30, 100 - rank * 0.5)
    row["mean_midfield_score"] = max(30, 100 - rank * 0.4)
    row["mean_attack_score"] = max(30, 100 - rank * 0.3)
    features = ["fifa_rank", "confederation", "mean_defense_score", "mean_midfield_score", "mean_attack_score"]
    X = row[features]
    prob = model.predict_proba(X)[0][1]
    return team_name, round(prob * 100, 1)

def compare(team1, team2):
    result1 = predict(team1)
    result2 = predict(team2)
    winner = result1 if result1[1] > result2[1] else result2
    st.write(f"{result1[0]}: {result1[1]}%")
    st.write(f"{result2[0]}: {result2[1]}%")
    st.success(f"Winner: {winner[0]}")
    return winner[0]

# Home Screen
if st.session_state.stage is None:
    st.title("Your Road to the 2026 FIFA World Cup Final")
    st.markdown("A glowing football slowly rotates in the background.")
    if st.button("Start Predictions"):
        st.session_state.stage = "quarterfinal"

# Quarterfinals
if st.session_state.stage == "quarterfinal":
    st.header("Quarterfinals")
    selected_teams = st.multiselect("Pick 4 teams to start your knockout", teams, max_selections=4)
    if len(selected_teams) == 4 and st.button("Predict Quarterfinals"):
        qf1 = compare(selected_teams[0], selected_teams[1])
        qf2 = compare(selected_teams[2], selected_teams[3])
        st.session_state.qf_winners = [qf1, qf2]
        st.session_state.stage = "semifinal"

# Semifinal
if st.session_state.stage == "semifinal":
    st.header("Semifinal")
    w1, w2 = st.session_state.qf_winners
    st.markdown(f"Match: {w1} vs {w2}")
    if st.button("Predict Semifinal"):
        sf_winner = compare(w1, w2)
        st.session_state.sf_winner = sf_winner
        st.session_state.stage = "final"

# Final
if st.session_state.stage == "final":
    st.header("Final")
    finalist = st.session_state.sf_winner
    opponent = st.selectbox("Choose final opponent", [t for t in teams if t != finalist])
    if st.button("Predict Final"):
        champion = compare(finalist, opponent)
        st.session_state.champion = champion
        st.session_state.final_opponent = opponent
        st.session_state.stage = "done"

# Done
if st.session_state.stage == "done":
    st.header("Champion")
    st.markdown(f"<div style='background-color:#dff0d8;padding:20px;border-radius:10px;font-size:20px;'>You predicted <strong>{st.session_state.champion}</strong> as the 2026 Champion.</div>", unsafe_allow_html=True)

    st.subheader("Your Bracket Summary")
    st.write("Quarterfinal Winners:", st.session_state.qf_winners)
    st.write("Semifinal Winner:", st.session_state.sf_winner)
    st.write("Final Opponent:", st.session_state.final_opponent)
    st.write("Champion:", st.session_state.champion)

    if st.button("Predict Again"):
        for key in ["stage", "qf_winners", "sf_winner", "champion", "final_opponent"]:
            st.session_state[key] = None